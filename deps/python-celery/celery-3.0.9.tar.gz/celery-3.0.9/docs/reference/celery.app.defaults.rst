===============================================================
 celery.app.defaults
===============================================================

.. contents::
    :local:
.. currentmodule:: celery.app.defaults

.. automodule:: celery.app.defaults
    :members:
    :undoc-members:
