==================================================
 celery.worker.consumer
==================================================

.. contents::
    :local:
.. currentmodule:: celery.worker.consumer

.. automodule:: celery.worker.consumer
    :members:
    :undoc-members:
