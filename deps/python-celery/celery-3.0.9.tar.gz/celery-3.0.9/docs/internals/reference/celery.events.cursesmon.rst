==========================================
 celery.events.cursesmon
==========================================

.. contents::
    :local:
.. currentmodule:: celery.events.cursesmon

.. automodule:: celery.events.cursesmon
    :members:
    :undoc-members:
