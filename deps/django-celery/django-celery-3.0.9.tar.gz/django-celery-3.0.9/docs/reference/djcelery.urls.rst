======================
 URLs - djcelery.urls
======================

.. contents::
    :local:
.. currentmodule:: djcelery.urls

.. automodule:: djcelery.urls
    :members:
    :undoc-members:
