from __future__ import absolute_import

try:
    import unittest
    unittest.skip
except AttributeError:
    import unittest2 as unittest  # noqa
