from django.db import models


class CustomComment(models.Model):
    pass
