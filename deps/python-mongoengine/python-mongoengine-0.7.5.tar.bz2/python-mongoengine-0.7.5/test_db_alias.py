#!/usr/bin/python

from mongoengine import *
from mongoengine.connection import disconnect


# Default database connection
connect('db1')
# Second database connection, db name and aliased as db2
connect('db2', 'db2')


class User(Document):
    meta = {'allow_inheritance': True}

    name = StringField()

class SubUser(User):
    meta = {'db_alias': 'db2'}


u = User(name='user1')
u.save()
su = SubUser(name='subuser1')
su.save()

print 'There are %d user(s).' % User.objects.count()
print 'There are %d subuser(s).' % SubUser.objects.count()

disconnect()
disconnect('db2')

print 'There are %d subuser(s).' % SubUser.objects.count()



