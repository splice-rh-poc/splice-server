from gis.tests.http import *
from gis.tests.views import *
