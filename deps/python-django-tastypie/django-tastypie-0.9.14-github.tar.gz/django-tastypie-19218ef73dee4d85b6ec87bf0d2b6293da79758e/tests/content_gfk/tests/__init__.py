import warnings
warnings.simplefilter('ignore', Warning)

from content_gfk.tests.fields import *
from content_gfk.tests.resources import *
