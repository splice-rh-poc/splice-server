from settings import *

INSTALLED_APPS += [
    'complex',
    'django.contrib.comments',
    'django.contrib.sites',
]

ROOT_URLCONF = 'complex.urls'
