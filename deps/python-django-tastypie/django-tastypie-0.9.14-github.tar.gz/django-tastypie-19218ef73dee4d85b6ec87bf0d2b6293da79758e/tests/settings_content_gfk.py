from settings import *

INSTALLED_APPS += [
    'content_gfk',
]

ROOT_URLCONF = 'content_gfk.urls'
