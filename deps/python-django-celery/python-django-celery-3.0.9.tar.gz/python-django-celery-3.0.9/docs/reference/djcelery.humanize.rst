====================================
 Humanize utils - djcelery.humanize
====================================

.. contents::
    :local:
.. currentmodule:: djcelery.humanize

.. automodule:: djcelery.humanize
    :members:
    :undoc-members:
