================================================
 Periodic Task Schedulers - djcelery.schedulers
================================================

.. contents::
    :local:
.. currentmodule:: djcelery.schedulers

.. automodule:: djcelery.schedulers
    :members:
    :undoc-members:
